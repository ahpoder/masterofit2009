Reading guidelines:

The order in which the documents should be read.

1.  Project proposal HW_SW Codesign.pdf
2.  Project description.pdf
3.  Project report.pdf
3.1 UseCases.pdf

The Project proposal is the initial document from the customer.

The Project description is the development team�s breakdown and clarification of the assignment.

The Project report contain the actual implementation of the project

The UseCases contain the Use cases and actors that is used in conjunction with the requirements in the Project report.
