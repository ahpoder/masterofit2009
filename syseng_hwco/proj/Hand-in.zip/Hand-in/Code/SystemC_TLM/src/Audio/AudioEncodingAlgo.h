#ifndef AUDIOENCODINGALGO_H
#define AUDIOENCODINGALGO_H

unsigned char* performAudioEncoding(short value, int* length);

#endif
