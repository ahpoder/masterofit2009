#ifndef AUDIODECODINGALGO_H
#define AUDIODECODINGALGO_H

int performAudioDecoding(const unsigned char* encodedData, int length, short* resultBuffer, int resultBufferLengt);

#endif
