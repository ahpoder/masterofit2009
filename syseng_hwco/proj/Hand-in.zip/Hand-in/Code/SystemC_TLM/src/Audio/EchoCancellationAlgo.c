#include "EchoCancellationAlgo.h"

int performEchoCancellation(int microphone, int speaker)
{
  return microphone - speaker;
}
