#ifndef ECHOCANCELLATIONALGO_H
#define ECHOCANCELLATIONALGO_H

int performEchoCancellation(int microphone, int speaker);

#endif
