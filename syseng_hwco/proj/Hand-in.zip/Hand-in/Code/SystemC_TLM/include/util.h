#ifndef UTIL_H
#define UTIL_H

#define htons(a) a
#define ntohs(a) a
#define htonl(a) a
#define ntohl(a) a

#endif
