#ifndef DEFS_H
#define DEFS_H

#define INPUT_FILE_ISM "ism_input_data.txt"
#define OUTPUT_FILE_ISM "ism_output_data.txt"

#endif
