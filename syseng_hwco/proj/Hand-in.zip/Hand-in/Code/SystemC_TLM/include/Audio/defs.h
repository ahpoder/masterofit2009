#ifndef DEFS_H
#define DEFS_H

#define INPUT_FILE_MICROPHONE "microphone_data.txt"

#define OUTPUT_FILE_SPEAKER "speaker_data.txt"

#endif
