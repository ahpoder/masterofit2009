Requirements:

1. The SystemC, SystemC_TLM and SystemC_TTLM_Micro must be run from a Cygwin shell with systemC installed
2. SystemCTLMFileGenerator require the .NET 2.0 Framework
