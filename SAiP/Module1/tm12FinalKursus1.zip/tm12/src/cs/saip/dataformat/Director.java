package cs.saip.dataformat;

import cs.saip.domain.TeleObservation;

/** The Director role of the Builder pattern.
 *
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */

public class Director {

  /** Construct a representation of a given teleobservation
   * using the provided builder.
   */
  public static void construct(TeleObservation to, Builder builder) {
      builder.buildHeader(to);
      builder.buildPatientInfo(to);
      builder.buildObservationList(to);
      builder.appendObservation(to.getSystolic());
      builder.appendObservation(to.getDiastolic());
  }
}
