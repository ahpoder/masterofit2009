package cs.saip.dataformat.delegate;

import cs.saip.dataformat.Builder;
import cs.saip.domain.*;
import cs.saip.xds.MetaData;

/** A builder to build metadata for a
 * tele observation.
 * 
 * @author Henrik Baerbak Christensen, AU
 */
public class MetadataBuilder implements Builder {
  private MetaData metadata;

  @Override
  public void buildHeader(TeleObservation to) {
    metadata = new MetaData();
  }

  @Override
  public void buildPatientInfo(TeleObservation to) {
    metadata.setPersonID( to.getId() );
    metadata.setTimestamp( to.getTime() );
  }

  @Override
  public void buildObservationList(TeleObservation to) {
    // not relevant for metadata
  }

  @Override
  public void appendObservation(ClinicalQuantity quantity) {
    // not relevant for metadata
  }

  public MetaData getResult() {
    return metadata;
    
  }
}
