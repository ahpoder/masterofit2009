package cs.saip.main;

import java.io.IOException;

import cs.saip.domain.*;
import cs.saip.ipc.*;
import cs.saip.ipc.delegate.*;
import cs.saip.ipc.http.HTTPInterProcessConnector;

/** A shell based home client prototype. 
 * Just sends a single observation
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class HomeClient {
  public static void main(String[] args) throws IOException {
    System.out.println("HomeClient: Sending a single observation for 'pid01' to the Web server...");
    
    TeleObservation to = new TeleObservation("pid01", 120.0, 70.0);
    
    Serializer serializer = new JacksonJSONSerializer();
    InterProcessConnector ipc = new HTTPInterProcessConnector("http://localhost:8080/tm12");
    
    Forwarder forwarder = new StandardForwarder(serializer, ipc);
    
    Result result = forwarder.send(to);
    System.out.println("HomeClient: upload success="+result.isSuccess());
  }
  
}
