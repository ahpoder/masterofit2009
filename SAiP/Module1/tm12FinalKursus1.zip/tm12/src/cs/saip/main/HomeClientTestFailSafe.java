package cs.saip.main;

import java.io.IOException;

import cs.saip.domain.TeleObservation;
import cs.saip.ipc.Forwarder;
import cs.saip.ipc.InterProcessConnector;
import cs.saip.ipc.Result;
import cs.saip.ipc.Serializer;
import cs.saip.ipc.delegate.JacksonJSONSerializer;
import cs.saip.ipc.delegate.StandardForwarder;
import cs.saip.ipc.http.HTTPInterProcessConnector;

public class HomeClientTestFailSafe{

	/**
	 * @param args
	 */
	  public static void main(String[] args) throws IOException {
		    System.out.println("HomeClient: Sending a single observation for 'pid01' to the Web server...");
		    Serializer serializer = new JacksonJSONSerializer();
		    InterProcessConnector ipc = new HTTPInterProcessConnector("http://localhost:8080/tm12");
		    Forwarder forwarder = new StandardForwarder(serializer, ipc);
		    
		    for (int i = 0; i < 300; i++) {
			    TeleObservation to = new TeleObservation("pid"+i, 120.0, 70.0);
			    Result result = forwarder.send(to);
			    System.out.println("HomeClient: upload success="+result.isSuccess());
			}
		  }
}
