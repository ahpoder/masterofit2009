package cs.saip.main;

import java.net.URL;
import javax.servlet.Servlet;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.servlet.*;

import cs.saip.avalibility.FailsafeReciver;
import cs.saip.avalibility.FileSystemXDSBackup;
import cs.saip.avalibility.MockMonitor;
import cs.saip.avalibility.StateResyncronisationAgent;
import cs.saip.avalibility.XDSMonitor;
import cs.saip.ipc.*;
import cs.saip.ipc.delegate.*;
import cs.saip.ipc.http.StandardHTTPServlet;
import cs.saip.xds.XDSBackend;
import cs.saip.xds.delegate.*;

/** A web server (Jetty based) that accepts HTTP requests:
 * 
 * POST requests are parsed as observations and delegated
 * to a StandardReceiver for further processing.
 * 
 * GET requests have the format "tm12?pid=xxxx" where
 * xxxx must be a valid person ID (try "pid01" :).
 * All HL7 observations for the given person will
 * be returned.
 * 
 *  Example: "http://localhost:8080/tm12?pid=pid01"
 * 
 * The program accepts two command line arguments:
 * type: {memory,mongodb} determines the type of
 *       database used (in-memory or MongoDB).
 *       (In the latter case, make sure MongoDB
 *       is running.)
 * port: Portnumber.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class JettyServerMain {
  
  public static void main(String[] args) throws Throwable {
	  
	JettyServerMain jsm = new JettyServerMain();
	  
	switch (args[0]) {
	case "mongodb":
	    jsm.startHenrikStyle(args[0],args[1]); // No error handling!
		break;
	case "memory":
		jsm.startHenrikStyle(args[0],args[1]); // No error handling!
		break;
	case "failsafe":
		jsm.startFailSafe(args[0],args[1],args[2],Integer.parseInt(args[3]),Integer.parseInt(args[4]));
		break;
	}
  }
  
  public JettyServerMain(){}
  
  private void startHenrikStyle(String type, String portNumber) throws Exception {
    // Define the server address
    String serverAddress = "http://localhost:"+portNumber;

    // Define the server side delegates
    Serializer serializer = null; Receiver receiver = null; XDSBackend xds = null;
    
    serializer = new JacksonJSONSerializer();
    if ( type.equals("mongodb") ) {
      xds = new MongoXDSAdapter("production"); 
    } else {
      xds = new FakeObjectXDSDatabase();
    }
    receiver = new StandardReceiver(serializer, xds);

    // Configure the servlet  
    Servlet servlet = new StandardHTTPServlet(receiver,
                                              xds);

    System.out.println("Starting the TM12 web server:" ); 
    System.out.println("  Address    :   " + serverAddress);
    System.out.println("  XDSBinding :   " + type);
    		
    // And configure Jetty with the servlet
    Server server = new Server(new URL(serverAddress).getPort());    
    Context root = new Context(server, "/", Context.SESSIONS);
    
    root.addServlet(new ServletHolder(servlet), "/tm12");
    server.start();
    server.join();
  }

  private void startFailSafe(String type, String portNumber,String backupFolder,int failAfter,int reopenAfter) throws Throwable{
	    // Define the server address
	    String serverAddress = "http://localhost:"+portNumber;

	    // Define the server side delegates
	    Serializer serializer = new JacksonJSONSerializer();
	    Receiver receiver = null;
	    XDSMonitor monitor = new MockMonitor(failAfter,reopenAfter);
	    XDSBackend xds = new MongoXDSAdapter("production");
	    XDSBackend xdsBackup = new FileSystemXDSBackup(backupFolder);
	    receiver = new FailsafeReciver(serializer, xds, xdsBackup, monitor);

	    StateResyncronisationAgent sra = new StateResyncronisationAgent(backupFolder,xds,true);
	    monitor.addConnectionListner(sra);
	    
	    // Configure the servlet  
	    Servlet servlet = new StandardHTTPServlet(receiver,
	                                              xds);

	    System.out.println("Starting the TM12 web server:" ); 
	    System.out.println("  Address    :   " + serverAddress);
	    System.out.println("  XDSBinding :   " + type);
	    		
	    // And configure Jetty with the servlet
	    Server server = new Server(new URL(serverAddress).getPort());    
	    Context root = new Context(server, "/", Context.SESSIONS);
	    
	    root.addServlet(new ServletHolder(servlet), "/tm12");
	    server.start();
	    server.join();
  }  
  
  
  /*
  private void startFailSafe(String type, String portNumber,String backupFolder){
	    // Define the server address
	    String serverAddress = "http://localhost:"+portNumber;

	    // Define the server side delegates
	    Serializer serializer = null; Receiver receiver = null; XDSBackend xds = null;
	    
	    serializer = new JacksonJSONSerializer();

		String backupFolder="c:/temp/testResyncronisationWithFiles/" ;
		File dir = new File(backupFolder);
		if(dir.exists())
			for(File f: dir.listFiles())
				f.delete();
		dir.mkdir();

		Serializer serializer = null;
	    Receiver receiver = null;
	    FakeObjectXDSDatabase xds = null;
	    XDSBackend xdsBackup = null;
	    MockMonitor monitor=null;
	    
	    StateResyncronisationAgent sra = null;

	    monitor=new MockMonitor(2);
	    
	    serializer = new JacksonJSONSerializer();
	    xds =  new FakeObjectXDSDatabase();
	    xdsBackup =new FileSystemXDSBackup(backupFolder); 
	    receiver = new FailsafeReciver(serializer, xds, xdsBackup , monitor);

	    sra= new StateResyncronisationAgent(backupFolder,xds);
	    monitor.addConnectionListner(sra);

	    TeleObservation to1 = new TeleObservation("TO1",1.0 ,1.0);
	    receiver.receive(ser.serialize(to1));
	    TeleObservation to2 = new TeleObservation("TO2",1.0 ,1.0);
	    receiver.receive(ser.serialize(to2));

	    //Document d = xds.getLastStoredObservation();
	    
	    //backend d�r ,, backup bruges istedet..
	    TeleObservation to3 = new TeleObservation("TO3",1.0 ,1.0);
	    receiver.receive(ser.serialize(to3));
	    
	    //Reset backend connection to reload locally backuped files.
	    monitor.resetCount();
	    
	    receiver = new StandardReceiver(serializer, xds);

	    // Configure the servlet  
	    Servlet servlet = new StandardHTTPServlet(receiver,
	                                              xds);

	    System.out.println("Starting the TM12 web server:" ); 
	    System.out.println("  Address    :   " + serverAddress);
	    System.out.println("  XDSBinding :   " + type);
	    		
	    // And configure Jetty with the servlet
	    Server server = new Server(new URL(serverAddress).getPort());    
	    Context root = new Context(server, "/", Context.SESSIONS);
	    
	    root.addServlet(new ServletHolder(servlet), "/tm12");
	    server.start();
	    server.join();
  }
  */
  
}
