package cs.saip.avalibility;

import java.util.ArrayList;


/**
 * Class used for testing. Mock object for the xsdmonitor interface.
 * @author EMOH
 *
 */
public class MockMonitor implements XDSMonitor {

	private ArrayList<XSDConnectionListner> listners= new ArrayList<XSDConnectionListner>();
	
	private int closeAfter=Integer.MAX_VALUE;
	private int reopenAfter=Integer.MAX_VALUE;
	private int requestCount=0;

	public MockMonitor(){}

	/**
	 * Constructer
	 * @param closeAfterNumberOfRequests :  Number of isAcceptingData calles returning true ,before reutrning false; 
	 */
	public MockMonitor(int closeAfterNumberOfRequests){
		closeAfter= closeAfterNumberOfRequests;
	}	

	public MockMonitor(int closeAfterNumberOfRequests,int reopenAfter){
		closeAfter= closeAfterNumberOfRequests;
	}	

	@Override
	public boolean isAcceptingData() {
		// TODO Auto-generated method stub
	requestCount++;
		if(  (requestCount <= closeAfter) || (requestCount>reopenAfter)  ){
			return true;			
		}else
		{
			return false;
		}	
	}

	public void resetCount(){
		requestCount=0;
		this.notifyListners();
	}
	
	
	@Override
	public void addConnectionListner(XSDConnectionListner xsdcl) {
		if(xsdcl!=null)
		listners.add(xsdcl);
	}

	@Override
	public void removeConnectionListner(XSDConnectionListner xsdcl) {
		if(xsdcl!=null && listners.contains(xsdcl))
		listners.remove(xsdcl);
	}

	public void notifyListners(){
		for ( int i=0; i<listners.size(); i++ )
		      listners.get(i).ConnectionChanged(true);
	}
	
	
}
