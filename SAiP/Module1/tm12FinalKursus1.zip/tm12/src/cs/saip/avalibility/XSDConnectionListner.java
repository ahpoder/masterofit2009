package cs.saip.avalibility;

public interface XSDConnectionListner {
	public void ConnectionChanged(boolean isOpen);
}
