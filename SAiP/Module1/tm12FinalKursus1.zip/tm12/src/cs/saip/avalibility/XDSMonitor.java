package cs.saip.avalibility;


/**
 * Interface responsible for communicating if xsdbackend is open for buisness(Accepting measuements). 
 * @author EMOH
 *
 */
public interface XDSMonitor{
	public boolean isAcceptingData();
	
	public void addConnectionListner(XSDConnectionListner xsdcl);
	public void removeConnectionListner(XSDConnectionListner xsdcl);
}
