/**
 * @author EMOH
 *
 */
package cs.saip.avalibility;