package cs.saip.avalibility;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import cs.saip.xds.MetaData;
import cs.saip.xds.XDSBackend;

public class StateResyncronisationAgent implements XSDConnectionListner{

	private String workingFolder; 
	private XDSBackend backend;
	
	private FutureTask<String> worker;
	private ExecutorService executor; 
	
	private DocumentBuilderFactory dbf;
	private DocumentBuilder docReader;
	private boolean useAsyncOperation;
	
	public StateResyncronisationAgent(String backupFolder, XDSBackend backend,boolean useAsyncOperation){
		this.useAsyncOperation=useAsyncOperation;
		this.workingFolder=backupFolder;
		this.backend =backend;
		executor = Executors.newFixedThreadPool(1); 
	}	
	
	@Override
	public void ConnectionChanged(boolean isOpen) {
		// TODO Auto-generated method stub
		//start thread that reloads files..
		
		//I canot get thread.wait to work.. => do it syncron instead of async..
		if(useAsyncOperation){
			reloadBackupStorage();
		}else{

			if(isOpen){
				if(worker==null)
					createWorker();
				else{
					if(worker.isDone() || worker.isCancelled() )
					{
						worker=null;
						createWorker();
					}
				}
			}
			else
			{
				worker.cancel(false);
			}
			
		}
		
		return;
	}	

	private void createWorker(){
		String result ="";
		worker = new FutureTask<String>(
				new Runnable(){
					public void run(){
						reloadBackupStorage();
					}
				}
				,result);
		executor.execute(worker);
	}
	
	private void reloadBackupStorage(){
	try {
		dbf =	javax.xml.parsers.DocumentBuilderFactory.newInstance();
		docReader=dbf.newDocumentBuilder();
	
		File dir = new File(workingFolder);
		for(File f : dir.listFiles()){
			try {
				Document hl7 =  docReader.parse(f);
				MetaData md = new MetaData();
				
				int idx =	f.getName().lastIndexOf("_");
				md.setPersonID(f.getName().substring(0,idx));
				md.setTimestamp(Long.parseLong( f.getName().substring(idx+1,f.getName().length()-4)));
				backend.provideAndRegisterDocument(md, hl7);
				
				f.delete();

			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
		}
			
		
	
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	}

}
