package cs.saip.avalibility;

import org.w3c.dom.Document;

import cs.saip.dataformat.Director;
import cs.saip.dataformat.delegate.HL7Builder;
import cs.saip.dataformat.delegate.MetadataBuilder;
import cs.saip.domain.TeleObservation;
import cs.saip.ipc.Receiver;
import cs.saip.ipc.Serializer;
import cs.saip.xds.MetaData;
import cs.saip.xds.XDSBackend;

public class FailsafeReciver implements Receiver {

	  private XDSBackend xds;
	  private XDSBackend backupXSD;
	  private Serializer serializer;
	  private XDSMonitor monitor;
	
	public FailsafeReciver(Serializer serializer, XDSBackend xds,XDSBackend backupXSD,XDSMonitor monitor){
		this.xds=xds;
		this.backupXSD=backupXSD;
		this.serializer =serializer;
		this.monitor=monitor;
	}
	
	@Override
	public void receive(String messagePayload) {
		// Unmarshall into an observation.
	    TeleObservation teleObs = serializer.deserialize(messagePayload);
	    
	    // Generate the XML document representing the
	    // observation in HL7 (HealthLevel7) format.
	    HL7Builder builder = new HL7Builder();   
	    Director.construct(teleObs, builder);
	    Document hl7Document = builder.getResult();
	    
	    // Generate the metadata for the obseravation
	    MetadataBuilder metaDataBuilder = new MetadataBuilder();
	    Director.construct(teleObs, metaDataBuilder);
	    MetaData metadata = metaDataBuilder.getResult();
	    
	    // Finally store the document in the XDS storage system
	    if(monitor.isAcceptingData()){
		    xds.provideAndRegisterDocument(metadata, hl7Document);
	    }else{
		    backupXSD.provideAndRegisterDocument(metadata, hl7Document);
	    }
	}

}
