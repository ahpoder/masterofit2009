package cs.saip.avalibility;

import java.io.File;
import java.util.List;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;


import cs.saip.xds.MetaData;
import cs.saip.xds.XDSBackend;

public class FileSystemXDSBackup implements XDSBackend {

	private String workingFolder; 
	private TransformerFactory tf;
	
	public FileSystemXDSBackup(String backupFolder){
		workingFolder=backupFolder;
		tf=TransformerFactory.newInstance();
	}
	
	@Override
	public void provideAndRegisterDocument(MetaData metaData,
			Document observationAsHL7) {
		// TODO Auto-generated method stub
		
		try {
			// Ved prod kode skal filnavnet v�re bedre.. Men AP s� lad g�.
			String fileName = "" + workingFolder + "/" + metaData.getPersonID() + "_" + metaData.getTimestamp() + ".xml";
			Transformer t = tf.newTransformer();
			Source s = new DOMSource(observationAsHL7);

			File f = new File(fileName);
			f.createNewFile();
			Result dest = new StreamResult(f);			
			t.transform(s, dest);
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(Exception e){
			e.printStackTrace();
		}
	}

	@Override
	public List<Document> retriveDocumentSet(String personID, long start,
			long end) {
		// TODO Auto-generated method stub
		// Degraded mode ,, not important..
		return null;
	}

}
