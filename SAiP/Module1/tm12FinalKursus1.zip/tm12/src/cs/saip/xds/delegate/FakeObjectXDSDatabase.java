package cs.saip.xds.delegate;

import java.util.*;

import org.w3c.dom.Document;

import cs.saip.xds.*;

/** An fake object implementation of the XDS storage
 * system, that is, it is a lightweight in-memory
 * implementation. (Which of course is not persistent!)
 * 
 * It also acts as a 'spy' as the last stored data
 * can be accessed.
 * 
 * See http://en.wikipedia.org/wiki/Test_double
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class FakeObjectXDSDatabase implements XDSBackend {
  
  private Document lastStoredObservation;
  private MetaData lastMetaData;

  class Pair { 
    public MetaData meta; public Document doc; 
    public Pair(MetaData m, Document d) {meta=m;doc=d;}
  }
  private ArrayList<Pair> db = new ArrayList<Pair>();

  @Override
  public void provideAndRegisterDocument(MetaData metaData, Document observationAsHL7) {
    lastMetaData = metaData;
    lastStoredObservation = observationAsHL7;
    // Store the observation in an internal 'database'
    db.add( new Pair(metaData, observationAsHL7));
  }

  /** Spy / retrival interface to get the
   * last stored observation
   * @return last observation that has been stored
   */
  public Document getLastStoredObservation() {
    return lastStoredObservation;
  }

  /** Spy / retrival interface to get the
   * last stored metadata
   * @return last metadata that has been stored
   */
 public MetaData getLastMetaData() {
    return lastMetaData;
  }

  @Override
  public List<Document> retriveDocumentSet(String personID, long start, long end) {   
    List<Document> thelist = new ArrayList<Document>();
    for ( Pair entry : db ) {
      MetaData md = entry.meta;
      if ( start <= md.getTimestamp() && 
          md.getTimestamp() <= end &&
          personID.equals( md.getPersonID() )) {
        thelist.add(entry.doc);
      }
    }
    
    return thelist;
  }

}
