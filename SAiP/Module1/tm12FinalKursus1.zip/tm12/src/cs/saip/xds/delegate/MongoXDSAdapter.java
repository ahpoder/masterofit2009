package cs.saip.xds.delegate;

import java.net.UnknownHostException;
import java.util.*;

import org.w3c.dom.Document;

import com.mongodb.*;

import cs.saip.domain.Utility;
import cs.saip.xds.*;

/** An Adapter that implements the XDSBackend interface and translates
 * storage and query to the Mongo DB format.
 *
 * MongoDB is a NoSQL database system, please
 * consult http://http://www.mongodb.org/.
 * 
 * @author Henrik Baerbak Christensen, AU
 */
public class MongoXDSAdapter implements XDSBackend {
 
  private DBCollection coll;
  private Mongo m;
 
  private final static String PID_KEY = "pid";
  private final static String TIME_KEY = "time";
  private final static String DOC_KEY = "doc";
  
  public MongoXDSAdapter(String databaseName) {
    // connect to the local database server
    m = null;
    try {
      m = new Mongo();
    } catch (UnknownHostException e) {
      e.printStackTrace();
    } catch (MongoException e) {
      e.printStackTrace();
    }

    m.setWriteConcern(WriteConcern.SAFE);
    // get handle to the requried database
    DB db = m.getDB( databaseName );

    // get a collection object to work with
    coll = db.getCollection("observations");

    // Register a shutdown hook to close the mongo 
    // connection
    Runtime.getRuntime().addShutdownHook(new Thread() {
      public void run() {
        // System.out.println("Closing Mongo DB");
        m.close();
      }});
  }

  /** Remove all data related to observations from
   * the Mongo db.
   */
  public void dropAllData() {
    coll.drop();
  }

  @Override
  public void provideAndRegisterDocument(MetaData metaData,
      Document observationAsHL7) {
    // Create the BSON object for the entry
    BasicDBObject dbo = new BasicDBObject();
    dbo.put(PID_KEY, metaData.getPersonID());
    dbo.put(TIME_KEY, metaData.getTimestamp());
    dbo.put(DOC_KEY, Utility.convertXMLDocumentToString(observationAsHL7));
    // And insert it into Mongo
    coll.insert(dbo);
  }

  @Override
  public List<Document> retriveDocumentSet(String personID, long start, long end) {
    List<Document> list = new ArrayList<Document>();

    // Define a Mongo query
    BasicDBObject query = new BasicDBObject();
    // set criteria on pid
    query.put(PID_KEY, personID);
    // and on timestamp
    query.put(TIME_KEY, new BasicDBObject("$gte", start).append("$lte",end));
    
    // Send the query and retrieve all documents matching
    DBCursor cursor = coll.find(query);
    try {
      while (cursor.hasNext()) {
        DBObject entry = cursor.next();
        String hl7 = (String) entry.get(DOC_KEY);
        list.add( Utility.convertXMLStringToDocument(hl7));
      }
    } finally {
      cursor.close();
    }
    return list;
  }

}
