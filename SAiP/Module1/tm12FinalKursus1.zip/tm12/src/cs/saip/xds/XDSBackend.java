package cs.saip.xds;

import java.util.*;

import org.w3c.dom.Document;

/** Facade for the XDS (Cross-Enterprise Document Storage)
 * system. This is a database system that stores XML documents
 * representing the tele observations for patients.
 * 
 * The present interface is of course a very scaled
 * down variant of a real XDS interface, especially
 * on the query side.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public interface XDSBackend {
  
  /** Store  observation in XMLformat (HL7) in a XDS repository and
   * ensure that the metadata for it is stored in the registry.
   */
  public void provideAndRegisterDocument(MetaData metaData, Document observationAsHL7);
  
  /** Query the XDS for all documents whose metadata fulfill criteria:
   * A) the id of the person equals personID
   * B) the timestamp is within the time interval [start;end]
   * @param personID id of the person searched for
   * @param start begin of timeinterval (UNIX long time format)
   * @param end end of timeinterval
   * @return list of all documents that fulfill criteria
   */
  public List<Document> retriveDocumentSet(String personID, long start, long end);
}
