package cs.saip.ipc;

import java.io.IOException;

import cs.saip.domain.*;

/** The forwarder can send observations to the
 * server. See "Patterns of Software Architecture"
 * for a description of the Forwarder pattern.
 * 
 * The form here is adapted slightly as it is
 * an synchroneous call.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public interface Forwarder {
  /** Send a teleobservation to the server for storage.
   * 
   * @param teleObservation the observation of medical
   * quantities
   * @return result of the send operation.
   * @throws IOException
   */
  public Result send(TeleObservation teleObservation) throws IOException;
}
