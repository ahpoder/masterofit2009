package cs.saip.ipc.delegate;

import java.io.IOException;

import cs.saip.domain.*;
import cs.saip.ipc.*;

/** Standard implementation of the forwarder that is
 * compositionally configured using dependency
 * injection. See chapter 16 in "Flexible, Reliable
 * Software - Using Patterns and Agile Development"
 * CRC Press 2010.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class StandardForwarder implements Forwarder {

  private Serializer serializer;
  private InterProcessConnector ipc;
  
  /** Create a forwarder and configure it with its
   * serializer and interprocess connector.
   * 
   * @param serializer the serializer to use
   * @param ipc the inter process communication connector
   * to use
   */
  public StandardForwarder(Serializer serializer, InterProcessConnector ipc) {
    this.serializer = serializer;
    this.ipc = ipc;
  }

  @Override
  public Result send(TeleObservation teleObservation) throws IOException {
    String onTheWireFormat = serializer.serialize(teleObservation);  
    Result result = ipc.sendToServer( onTheWireFormat );
    return result;
  }

}
