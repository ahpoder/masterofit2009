package cs.saip.ipc.delegate;

import cs.saip.ipc.Result;

/** Standard implementation of Result.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class StandardResult implements Result {

  private boolean success;
  public StandardResult(boolean isSuccess) {
    success = isSuccess;
  }
  @Override
  public boolean isSuccess() {
    return success;
  }

}
