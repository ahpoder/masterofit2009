package cs.saip.ipc;


/** The role of a receiver on the server side.
 * See the Forwarder-Receiver pattern in the POSA book.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public interface Receiver {
  public void receive(String messagePayload);
}
