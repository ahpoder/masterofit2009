package cs.saip.ipc.http;

import java.io.IOException;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;

import org.w3c.dom.Document;

import cs.saip.domain.*;
import cs.saip.ipc.*;
import cs.saip.xds.XDSBackend;

/** A TM12 HTTP servlet that is configured by
 * injecting the proper serializer and receiver.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */


public class StandardHTTPServlet extends HttpServlet {

  private static final long serialVersionUID = 1L;

  private Receiver receiver;
  private XDSBackend xds;
  
  /** Create a HTTP servlet, configured with a proper
   * receiver and XDS backend.
   * @param receiver receiver to use for further processing
   * of incoming request
   * @param xds the XDS to query for observations
   */
  public StandardHTTPServlet(Receiver receiver, XDSBackend xds) {
    super();
    this.receiver = receiver;
    this.xds = xds;
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    System.out.println("In doPost: req=\n"+req);
    // Receive and store latest observation
    StringBuffer data = new StringBuffer();
    for (String line; (line = req.getReader().readLine()) != null;) {
      data.append(line);
    }
    // System.out.println("Received payload: " + data.toString());
    
    // Delegate to the receiver to process it
    receiver.receive(data.toString());
    
    // TODO: Validate that this is a proper response
    String result = "200 OK";
    resp.setHeader("Access-Control-Allow-Origin", "*");
    resp.getOutputStream().write(result.getBytes());
    resp.flushBuffer();
  }

  
  @SuppressWarnings("unchecked")
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    Map<String, String> queryMap = new HashMap<String, String>();
    for (String key : (Iterable<String>) req.getParameterMap().keySet()) {
      queryMap.put(key, ((String[]) req.getParameterMap().get(key))[0]);
    }
    // System.out.println( "Received Query = "+queryMap.toString() );
 
    String result;

    if ( queryMap.isEmpty() ) {
      result = "This is the TM12 jetty based server, used in SAiP 2012. Please upload observations using POST.";
    } else {
      Date d = new Date();
      List<Document> list = xds.retriveDocumentSet(queryMap.get("pid"), 0L, d.getTime());
      result = "<html><body>";
      result += "<H3>There are "+list.size() + " observations.</H3>\n";
      for ( Document doc1 : list ) {
        result += "<hr/><pre>";
        // sigh - have to convert all < to the &lt; etc. 
        String tmp = Utility.convertXMLDocumentToString(doc1);
        tmp = tmp.replaceAll("<", "&lt;");
        tmp = tmp.replaceAll(">", "&gt;");
        // System.out.println( tmp );
        result += tmp;
        result += "</pre>";
      }
      result += "</body></html>";
    }
    
    resp.setStatus(HttpServletResponse.SC_OK);
    resp.setHeader("Access-Control-Allow-Origin", "*");
    resp.getOutputStream().write(result.getBytes());
    resp.flushBuffer();
  }

}
