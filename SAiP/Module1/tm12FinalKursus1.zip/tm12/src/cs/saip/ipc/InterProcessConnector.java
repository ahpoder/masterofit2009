package cs.saip.ipc;

import java.io.IOException;

/** The role of an inter process connector.
 * In a distributed system an implementation will
 * encapsulate a HTTP connector, a socket, or similar.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public interface InterProcessConnector {
  
  /** Send the on-the-wire string to the server side.
   * 
   * @param onTheWireFormat the observation in the adopted
   * on-the-wire format.
   * @return a future that will eventually tell the status
   * of the transmission.
   */
  public Result sendToServer(String onTheWireFormat) throws IOException;


}
