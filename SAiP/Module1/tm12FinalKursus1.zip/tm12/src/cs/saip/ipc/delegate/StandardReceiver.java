package cs.saip.ipc.delegate;

import org.w3c.dom.Document;

import cs.saip.dataformat.*;
import cs.saip.dataformat.delegate.*;
import cs.saip.domain.*;
import cs.saip.ipc.*;
import cs.saip.xds.*;

/** Standard implementation of the receiver. All specific
 * behavior is configured by injecting proper delegates.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class StandardReceiver implements Receiver {

  private XDSBackend xds;
  private Serializer serializer;
  
  /** Create a receiver configured with the given serializer
   * for unmarshalling and given xds for storage.
   * @param serializer the serializer to use
   * @param xds the storage to use
   */
  public StandardReceiver(Serializer serializer, XDSBackend xds) {
    this.xds = xds;
    this.serializer = serializer;
  }

  @Override
  public void receive(String messagePayload) {
    // Unmarshall into an observation.
    TeleObservation teleObs = serializer.deserialize(messagePayload);
    
    // Generate the XML document representing the
    // observation in HL7 (HealthLevel7) format.
    HL7Builder builder = new HL7Builder();   
    Director.construct(teleObs, builder);
    Document hl7Document = builder.getResult();
    
    // Generate the metadata for the obseravation
    MetadataBuilder metaDataBuilder = new MetadataBuilder();
    Director.construct(teleObs, metaDataBuilder);
    MetaData metadata = metaDataBuilder.getResult();
    
    // Finally store the document in the XDS storage system
    xds.provideAndRegisterDocument(metadata, hl7Document);
  }

}
