package cs.saip.ipc;

import cs.saip.domain.TeleObservation;

/** The serializer is responsible for marshalling and unmarshalling
 * TeleObservations to and from the on-the-wire format that
 * is used between a home device and the server side.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public interface Serializer {

  public String serialize(TeleObservation sto);
  
  public TeleObservation deserialize(String messagePayload);
}
