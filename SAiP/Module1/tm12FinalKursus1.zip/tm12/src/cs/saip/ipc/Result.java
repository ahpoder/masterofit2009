package cs.saip.ipc;

/** The result of an send operation in the
 * forwarder.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public interface Result {
  /** Tell whether the transmission was uploaded successfully.
   * @return true if and only if the I/O operation was completed successfully. */
  public boolean isSuccess();

}
