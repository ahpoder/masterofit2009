package cs.saip.ipc.delegate;

import java.io.*;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.*;

import cs.saip.domain.*;
import cs.saip.ipc.Serializer;

/** An implementation of Serializer that uses
 * JSON (as implemented by Jackson) as 'on the wire' format.
 * 
 * @author Klaus Marius Hansen, University of Copenhagen
 *
 */

public class JacksonJSONSerializer implements Serializer {
  private ObjectMapper mapper;

  public JacksonJSONSerializer() {
    mapper = new ObjectMapper();
  }
  
  @Override public String serialize(TeleObservation tm) {
    String result = null;
    try {
      result = mapper.writeValueAsString(tm);
    } catch (JsonGenerationException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (JsonMappingException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return result;
  }

  
  @Override
    public TeleObservation deserialize(String messagePayload) {
    TeleObservation result = null;
    
    Thread.currentThread().setContextClassLoader(getClass().getClassLoader()); // Jackson sets the wrong classloader for OSGi purposes
    
    mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false); // Laissez faire for now: ignore properties that are not defined as beans on class
    mapper.enableDefaultTyping();
    try {
      result = mapper.readValue(messagePayload, TeleObservation.class);
    } catch (IOException e) {
      // Rethrow
      throw new RuntimeException(e);
    }
    return result;
  }
  
}
