package cs.saip.ipc.http;

import java.io.IOException;
import java.net.*;

import cs.saip.ipc.*;

/** An implementation of the InterProcessConnector that
 * uses HTTP as the protocol for connecting to a web server.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 */
public class HTTPInterProcessConnector implements InterProcessConnector {

  private URL url;

  /** Create a connector to the given server
   * 
   * @param server name of the server to connect to
   * @throws MalformedURLException
   */
  public HTTPInterProcessConnector(String server) throws MalformedURLException {
    url = new URL(server);
  }

  @Override
  public Result sendToServer(String onTheWireFormat) throws IOException {
    boolean result = false;
    String message = null;

    HttpURLConnection connection = openConnection(url);
    connection.setRequestProperty("accept", "application/json");
    connection.setDoOutput(true);
    connection.getOutputStream().write(onTheWireFormat.getBytes());

    result = (connection.getResponseCode() == HttpURLConnection.HTTP_OK);
    message = connection.getResponseCode()+connection.getResponseMessage();
    
    System.out.println(result);
    System.out.println(message);

    return new HttpConnectorFutureResult(result, message);
  }
  
  /**
   * 
   * Opens a URL connection. 
   * 
   * @param url
   * @return
   * @throws IOException
   */
  private HttpURLConnection openConnection(URL url) throws IOException {
    //make a check for the type of connection
    
    HttpURLConnection result;
    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    result = conn;
     
    return result;
  }


  class HttpConnectorFutureResult implements Result {
    private boolean isSuccess;

    public HttpConnectorFutureResult(boolean result, String message) {
      this.isSuccess = result;
    }

    @Override
    public boolean isSuccess() {
      return isSuccess;
    }
 }

}
