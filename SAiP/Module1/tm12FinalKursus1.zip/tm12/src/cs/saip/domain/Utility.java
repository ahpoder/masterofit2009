package cs.saip.domain;

import java.io.*;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;
import org.xml.sax.*;

/** Various utility functions. 
 * 
 * Contains:
 *
 * Functions to convert from XML Document to nicely formatted XML string;
 * and back again.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */

public class Utility {

  /** Convert an XML document to a human readable string with
   * proper indentation.
   * @param doc the XML document to convert
   * @return the string representation of the document.
   */
  public static String convertXMLDocumentToString(Node doc)  {

    Transformer trans = null;
    try {
      trans = transfac.newTransformer();
    } catch ( TransformerException e ) {
      throw new RuntimeException(e);
    }
    trans.setOutputProperty(OutputKeys.INDENT, "yes");
    trans.setOutputProperty( "{http://xml.apache.org/xslt}indent-amount", "2" ); 

    //create string from xml tree
    StringWriter sw = new StringWriter();
    StreamResult result = new StreamResult(sw);
    DOMSource source = new DOMSource(doc);
    try {
      trans.transform(source, result);
    } catch ( TransformerException e ) {
      throw new RuntimeException(e);
    }
    //sw.close();

    String xmlString = sw.toString();

    return xmlString;
  }
  

  private static TransformerFactory transfac = TransformerFactory.newInstance();
  private static DocumentBuilderFactory factory =
      DocumentBuilderFactory.newInstance();

  /** convert a valid XML string into the equivalent Document object
   * 
   * @param xml well formed XML string
   * @return corresponding Document instance or null of failed
   * @throws Net4CareException 
   */
  public static Document convertXMLStringToDocument(String xml)  {
    // Convert the XML string to w3c Document
    Document doc = null;
    try {
      DocumentBuilder builder = factory.newDocumentBuilder();
      doc = builder.parse(new InputSource(new StringReader(xml)));
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    catch ( Exception e ) {
      throw new RuntimeException(e);
    }
    return doc;
  }
  
  /** Get the value of a specific attribute with an enclosing node.
   * Example:
   * 
   * The PHMR contains a deeply nested observation node like this
               <observation classCode="OBS" moodCode="EVN">
                  <templateId root="2.16.840.1.113883.10.20.1.31"/>
                  <templateId root="2.16.840.1.113883.10.20.9.8"/>
                  <code code="20150-9" codeSystem="2.16.840.1.113883.6.1" displayName="FEV1"/>
                  <value unit="L" value="3.42" xsi:type="PQ"/>
               </observation>

   * The following test will pass: 
   *  assertEquals( "L", getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc( "unit", 1, "value", "observation", phmrDoc) );
  
   * @param attributeName name of the attribute whose value is returned
   * @param nodeIndex the number of the node named 'nodeName' in the child list of node 'enclosingNodeName'
   * @param nodeName name of the node with the attribute
   * @param enclosingNodeName name of the node that encloses the node
   * @param doc the XML document
   * @return the value of the attribute or null if not found.
   */
  public static String getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc( String attributeName, int nodeIndex, String nodeName,
      String enclosingNodeName, Document doc) {
    NodeList list = doc.getElementsByTagName(enclosingNodeName);
      NodeList childrenOfEnclosed = list.item(nodeIndex).getChildNodes();
      for ( int j = 0; j < childrenOfEnclosed.getLength(); j++ ) {
        if ( childrenOfEnclosed.item(j).getNodeName().equals(nodeName) ) {
          NamedNodeMap nnm = childrenOfEnclosed.item(j).getAttributes();
          return nnm.getNamedItem(attributeName).getNodeValue();
        }
    }
    return null;
  }

}
