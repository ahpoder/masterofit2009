package cs.saip.domain;

import java.util.GregorianCalendar;

/** The domain object for a tele observation for bloodpressure. 
 * This encapsulates a persons identity (which person does
 * this measurements belong to), the time of the observation,
 * and of course the systolic and diastolic measurements.
 * 
 * @author Henrik Baerbak Christensen, AU
 */

public class TeleObservation {
  
  private String id;
  private ClinicalQuantity systolic;
  private ClinicalQuantity diastolic;
  private long time;

  public TeleObservation(String id, double systolic, double diastolic) {
    this.id = id;
    this.time = new GregorianCalendar().getTimeInMillis();
    this.systolic = new ClinicalQuantity(systolic, "mm(Hg)","MSC88019","Systolisk BT");
    this.diastolic = new ClinicalQuantity(diastolic, "mm(Hg)","MSC88020","Diastolisk BT");
  }
  
  /** Default constructor required for deserialization */
  public TeleObservation() {
    
  }
  
  /** The identity of the person/ptt that
   * this measurement has been made on.
   * Obvious candidate is the Danish CPR number.
   * @return person identity (CPR)
   */
  public String getId() {
    return id;
  }
 
  /** The time when this observation was
   * made. UNIX long timeformat used.
   * @return time of observation.
   */
  public long getTime() {
    return time;
  }

  /** Set the time. Should not be used expect for
   * testing purposes.
   * @param time
   */
  public void setTime(long time) {
    this.time = time;
  }


  /** The systolic blood pressure */
  public ClinicalQuantity getSystolic() {
    return systolic;
  }

  /** The diastolic blood pressure */
  public ClinicalQuantity getDiastolic() {
    return diastolic;
  }
  
  public String toString() {
    return "TeleObservation for PatientID="+getId()+" Measured=("+getSystolic() + ","+getDiastolic()+")";
  }

  
}