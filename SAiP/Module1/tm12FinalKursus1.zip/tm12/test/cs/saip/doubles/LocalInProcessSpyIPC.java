package cs.saip.doubles;

import java.io.IOException;

import cs.saip.ipc.*;
import cs.saip.ipc.delegate.StandardResult;

/** A test double implementation of the IPC role that uses simple
 * message calls to transfer the message payload to the "server".
 * 
 * Additionally it acts as a Spy and has a retrieval interface
 * to inspect the payload sent to the server for validation.
 * 
 * See description of the test double and test spy terminology
 * in chapter 12 of "Flexible, Reliable
 * Software - Using Patterns and Agile Development"
 * CRC Press 2010.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class LocalInProcessSpyIPC implements InterProcessConnector {
  
  private String lastSentPayload;
  private Receiver receiver;

  public LocalInProcessSpyIPC(Receiver receiver) {
    this.receiver = receiver;
  }

  @Override
  public Result sendToServer(String onTheWireFormat) throws IOException {
    // Store the message locally to allow spying on it.
    lastSentPayload = onTheWireFormat;
    
    // next "send it" to the server's receiver, here just
    // an in memory local object method call to facilitate
    // end-to-end testing in an local environment
    receiver.receive(onTheWireFormat);
    
    // TODO: Handle error messages...
    
    return new StandardResult(true);
  }
  
  /** read the value of the last sent message.
   * This is the 'specialized access routines' tactic
   * from Bass chapter 5.
   * @return last sent message.
   */
  public String retrieveLastSentPayload() {
    return lastSentPayload;
  }

}
