package cs.saip.helper;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;

import org.w3c.dom.Document;

import cs.saip.domain.*;

/** Container of methods that are used in multiple
 * test cases to establish and validate observations
 * with known properties.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */

public class HelperMethods {

  public static final String NANCY_CPR = "251248-0000";
  public static long timestamp;
  
  /** Create an tele observation of 120 over 70 for Nancy */
  public static TeleObservation createObservation120over70forNancy() {
    TeleObservation to = new TeleObservation(HelperMethods.NANCY_CPR, 120.0, 70.0);
    
    // Change the time stamp to something known
    final Calendar cal = Calendar.getInstance();
    cal.set(2012,5,1,7,30,00); 
    timestamp = cal.getTimeInMillis();
    to.setTime( timestamp );
    
    return to;
  }

  /** Validate that an HL7 document contains the tags containing information
   * for Nancy's blood pressure of 120 over 70.
   * @param doc
   */
  public static void assertThatDocumentRepresentsObservation120over70forNancy(Document doc) {
    // assert root element correct
    assertEquals("ClinicalDocument", doc.getDocumentElement().getNodeName());
    
    // assert timestamp stored correctly
    assertEquals("20120601073000", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("value", 0, "effectiveTime", "ClinicalDocument", doc));
    
    // assert proper patient id stored
    assertEquals(NANCY_CPR, Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("extension", 0, "id", "patient", doc));
    
    // assert systolic data
    assertEquals( "MSC88019", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("code", 0, "code", "observation", doc));
    assertEquals( "Systolisk BT", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("displayName", 0, "code", "observation", doc));
    assertEquals( "mm(Hg)", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("unit", 0, "value", "observation", doc));
    assertEquals( "120.0", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("value", 0, "value", "observation", doc));

    // assert diastolic data
    assertEquals( "MSC88020", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("code", 1, "code", "observation", doc));
    assertEquals( "Diastolisk BT", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("displayName", 1, "code", "observation", doc));
    assertEquals( "mm(Hg)", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("unit", 1, "value", "observation", doc));
    assertEquals( "70.0", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("value", 1, "value", "observation", doc));
  }


}
