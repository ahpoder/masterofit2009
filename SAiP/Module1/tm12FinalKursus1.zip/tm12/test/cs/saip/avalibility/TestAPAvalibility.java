package cs.saip.avalibility;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;

import org.junit.Test;
import org.w3c.dom.Document;

import cs.saip.domain.TeleObservation;
import cs.saip.ipc.Receiver;
import cs.saip.ipc.Serializer;
import cs.saip.ipc.delegate.JacksonJSONSerializer;
import cs.saip.xds.XDSBackend;
import cs.saip.xds.delegate.FakeObjectXDSDatabase;

public class TestAPAvalibility {
	
	private JacksonJSONSerializer ser = new JacksonJSONSerializer();
	
/*
	@Test
	public void test() {
		fail("Not yet implemented");
	}
*/
	
	@Test
	public void testMockMonitor1() {
		MockMonitor mm = new MockMonitor(5);
		mm.isAcceptingData();
		mm.isAcceptingData();
		mm.isAcceptingData();
		mm.isAcceptingData();
		mm.isAcceptingData();
		assertTrue(!mm.isAcceptingData());
	}

	@Test
	public void testFailsafeReciverGoToBackup() {
		String backupFolder="";
	    Serializer serializer = null;
	    Receiver receiver = null;
	    XDSBackend xds = null;
	    FakeObjectXDSDatabase xdsBackup = null;
	    XDSMonitor monitor=null;
	    
	    StateResyncronisationAgent sra = null;
	    
	    serializer = new JacksonJSONSerializer();
	    xds = new FakeObjectXDSDatabase();
	    xdsBackup = new FakeObjectXDSDatabase(); 
	    monitor=new MockMonitor(2);
	    receiver = new FailsafeReciver(serializer, xds, xdsBackup , monitor);

	    sra= new StateResyncronisationAgent(backupFolder,xds,false);
	    monitor.addConnectionListner(sra);

	    TeleObservation to1 = new TeleObservation("TO1",1.0 ,1.0);
	    receiver.receive(ser.serialize(to1));
	    TeleObservation to2 = new TeleObservation("TO2",1.0 ,1.0);
	    receiver.receive(ser.serialize(to2));
	    //backend d�r ,, backup bruges istedet..
	    TeleObservation to3 = new TeleObservation("TO3",1.0 ,1.0);
	    receiver.receive(ser.serialize(to3));
	    TeleObservation to4 = new TeleObservation("TO4",1.0 ,1.0);
	    receiver.receive(ser.serialize(to4));
	    
	    assertTrue(xdsBackup.getLastStoredObservation()!=null);
		
	    //receiver.receive("");
	    //assertTrue(xdsBackup.getLastStoredObservation()!=null);
		
	}
	
	@Test
	public void testFailsafeReciverReturnToNormal() {
		String backupFolder="";
	    Serializer serializer = null;
	    Receiver receiver = null;
	    FakeObjectXDSDatabase xds = null;
	    FakeObjectXDSDatabase xdsBackup = null;
	    MockMonitor monitor=null;
	    
	    StateResyncronisationAgent sra = null;
	    
	    serializer = new JacksonJSONSerializer();
	    xds = new FakeObjectXDSDatabase();
	    xdsBackup = new FakeObjectXDSDatabase(); 
	    monitor=new MockMonitor(2);
	    receiver = new FailsafeReciver(serializer, xds, xdsBackup , monitor);

	    sra= new StateResyncronisationAgent(backupFolder,xds,false);
	    //To avoid reading files that is not there
	    //monitor.addConnectionListner(sra);

	    TeleObservation to1 = new TeleObservation("TO1",1.0 ,1.0);
	    receiver.receive(ser.serialize(to1));
	    TeleObservation to2 = new TeleObservation("TO2",1.0 ,1.0);
	    receiver.receive(ser.serialize(to2));
	    Document d = xds.getLastStoredObservation();
	    
	    //backend d�r ,, backup bruges istedet..
	    TeleObservation to3 = new TeleObservation("TO3",1.0 ,1.0);
	    receiver.receive(ser.serialize(to3));
	    
	    monitor.resetCount();

	    TeleObservation to4 = new TeleObservation("TO4",1.0 ,1.0);
	    receiver.receive(ser.serialize(to4));
	    
	    //TODO: Sammenligne docs p� andet end object.equals
	    assertTrue(xds.getLastStoredObservation()!=d);
	}
	
	//TODO: Teste state resync
/*	
	@Test
	public void testResyncronisation() throws InterruptedException {

		String backupFolder="";
	    Serializer serializer = null;
	    Receiver receiver = null;
	    FakeObjectXDSDatabase xds = null;
	    FakeObjectXDSDatabase xdsBackup = null;
	    MockMonitor monitor=null;
	    
	    StateResyncronisationAgent sra = null;

	    monitor=new MockMonitor(2);
	    
	    serializer = new JacksonJSONSerializer();
	    xds = new FakeObjectXDSDatabase();
	    xdsBackup = new FakeObjectXDSDatabase(); 
	    receiver = new FailsafeReciver(serializer, xds, xdsBackup , monitor);

	    sra= new StateResyncronisationAgent(backupFolder,xds);
	    monitor.addConnectionListner(sra);

	    TeleObservation to1 = new TeleObservation("TO1",1.0 ,1.0);
	    receiver.receive(ser.serialize(to1));
	    TeleObservation to2 = new TeleObservation("TO2",1.0 ,1.0);
	    receiver.receive(ser.serialize(to2));

	    //Document d = xds.getLastStoredObservation();
	    
	    //backend d�r ,, backup bruges istedet..
	    TeleObservation to3 = new TeleObservation("TO3",1.0 ,1.0);
	    receiver.receive(ser.serialize(to3));
	    
	    //monitor.resetCount();

	    //Thread.currentThread().wait(15000L);

	    // Wait for ResynronisationAgent to finish...
	    
	    //TODO: Sammenligne docs p� andet end object.equals
	    assertTrue(xds.getLastMetaData().getPersonID().equals(xdsBackup.getLastMetaData().getPersonID()));
	}	
*/	
	@Test
	public void testResyncronisationWithFiles() throws InterruptedException {

		String backupFolder="c:/temp/testResyncronisationWithFiles/" ;
		File dir = new File(backupFolder);
		if(dir.exists())
			for(File f: dir.listFiles())
				f.delete();
		dir.mkdir();

		Serializer serializer = null;
	    Receiver receiver = null;
	    FakeObjectXDSDatabase xds = null;
	    XDSBackend xdsBackup = null;
	    MockMonitor monitor=null;
	    
	    StateResyncronisationAgent sra = null;

	    monitor=new MockMonitor(2);
	    
	    serializer = new JacksonJSONSerializer();
	    xds =  new FakeObjectXDSDatabase();
	    xdsBackup =new FileSystemXDSBackup(backupFolder); 
	    receiver = new FailsafeReciver(serializer, xds, xdsBackup , monitor);

	    sra= new StateResyncronisationAgent(backupFolder,xds,false);
	    monitor.addConnectionListner(sra);

	    TeleObservation to1 = new TeleObservation("TO1",1.0 ,1.0);
	    receiver.receive(ser.serialize(to1));
	    TeleObservation to2 = new TeleObservation("TO2",1.0 ,1.0);
	    receiver.receive(ser.serialize(to2));

	    //Document d = xds.getLastStoredObservation();
	    
	    //backend d�r ,, backup bruges istedet..
	    TeleObservation to3 = new TeleObservation("TO3",1.0 ,1.0);
	    receiver.receive(ser.serialize(to3));
	    
	    //Reset backend connection to reload locally backuped files.
	    monitor.resetCount();

	    // Wait for ResynronisationAgent to finish...
	    Thread.sleep(3000);
	    
	    //TODO: Sammenligne docs p� andet end object.equals
	    assertTrue(xds.getLastMetaData().getPersonID().equals("TO3"));
	    //TODO: teste at der ikke er flere filer i backup folderen..
	    assertTrue(dir.listFiles().length == 0);  
	}	

	
	@Test
	public void testFailsafeReciverWriteToDisk() throws IOException {
		String backupFolder="c:/temp/testFailsafeReciverWriteToDisk/" ;
		File dir = new File(backupFolder);
		if(dir.exists())
			for(File f: dir.listFiles())
				f.delete();
		dir.mkdir();
		
		Serializer serializer = null;
	    Receiver receiver = null;
	    XDSBackend xds = null;
	    XDSBackend xdsBackup = null;
	    XDSMonitor monitor=null;
	    
	    StateResyncronisationAgent sra = null;
	    
	    serializer = new JacksonJSONSerializer();
	    xdsBackup = new FileSystemXDSBackup(backupFolder);
	    xds = new FakeObjectXDSDatabase(); 
	    monitor=new MockMonitor(2);
	    receiver = new FailsafeReciver(serializer, xds, xdsBackup , monitor);

	    sra= new StateResyncronisationAgent(backupFolder,xds,false);
	    monitor.addConnectionListner(sra);

	    TeleObservation to1 = new TeleObservation("TO1",1.0 ,1.0);
	    receiver.receive(ser.serialize(to1));
	    TeleObservation to2 = new TeleObservation("TO2",1.0 ,1.0);
	    receiver.receive(ser.serialize(to2));
	    //backend d�r ,, backup bruges istedet..
	    TeleObservation to3 = new TeleObservation("TO3",1.0 ,1.0);
	    receiver.receive(ser.serialize(to3));
	    TeleObservation to4 = new TeleObservation("TO4",1.0 ,1.0);
	    receiver.receive(ser.serialize(to4));
	    
	    assertTrue(dir.listFiles().length == 2 );
	}
	
	/*
	@Test
	public void testStoreForkromet() {
		String backupFolder="";
	    Serializer serializer = null;
	    Receiver receiver = null;
	    XDSBackend xds = null;
	    XDSBackend xdsBackup = null;
	    XDSMonitor monitor=null;
	    
	    StateResyncronisationAgent sra = null;
	    
	    serializer = new JacksonJSONSerializer();
	    xds = new FakeObjectXDSDatabase();
	    xdsBackup = new FileSystemXDSBackup(backupFolder); 
	    monitor=new MockMonitor();
	    receiver = new FailsafeReciver(serializer, xds, xdsBackup , monitor);

	    sra= new StateResyncronisationAgent(backupFolder,xds);
	    monitor.addConnectionListner(sra);

	    // requests til mongo
	    receiver.receive("");
	    receiver.receive("");
	    receiver.receive("");
	    receiver.receive("");
	    receiver.receive("");

	    //Backend is down,, writes files
	    receiver.receive("");
	    
	    //if backupfolder.files.count > 0
	    assertTrue(false);
	    
	    
	    
	    //System.out.println("  XDSBinding :   " + type);
	    		
	    // And configure Jetty with the servlet
		
		fail("Not yet implemented");
	}
*/
	
	
}
