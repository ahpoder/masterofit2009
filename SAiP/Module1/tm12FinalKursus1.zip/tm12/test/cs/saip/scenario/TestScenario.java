package cs.saip.scenario;

import java.io.IOException;
import java.util.*;

import org.junit.*;
import org.w3c.dom.Document;

import static org.junit.Assert.*;

import cs.saip.domain.*;
import cs.saip.doubles.*;
import cs.saip.helper.HelperMethods;
import cs.saip.ipc.*;
import cs.saip.ipc.delegate.*;
import cs.saip.xds.MetaData;
import cs.saip.xds.delegate.FakeObjectXDSDatabase;

/** Learning tests for the TM12 system.
 * Various tests that demonstrate behaviour of the system,
 * generally from the more fundamental level up till a
 * full upload of a tele observation scenario.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class TestScenario {

  private TeleObservation teleObs1; 
  
  // Client side forwarder
  private Forwarder forwarder;
  // Server side receiver
  private Receiver receiver;
  // The serializer used for marshalling and unmarshalling
  private Serializer serializer;

  // Delegates that configure the forwarder and
  // receiver with test doubles to allow
  // validation of the architecture's
  // behavior.
  private LocalInProcessSpyIPC ipc;
  private FakeObjectXDSDatabase xds;
  
  @Before public void setup() {
    teleObs1 = HelperMethods.createObservation120over70forNancy();
    
    // define the standard serializer
    serializer = new JacksonJSONSerializer();

    // A fake object (= in memory 'cheap' but
    // functional) implementation of the database system.
    xds = new FakeObjectXDSDatabase();
    // Define the receiver as it has to be known
    // to the ipc
    receiver = 
        new StandardReceiver(serializer, xds);

    // define the delegates to inject into the forwarder
    // configuring them for local machine single process
    // communication
    // A spy (= allow inspection of intermediate values)
    // implementation of the transfer layer (inter process
    // communication - that simply uses in memory
    // method calls.
    ipc = new LocalInProcessSpyIPC(receiver);

    // Inject the forwarder and receiver with the delegates
    forwarder = 
        new StandardForwarder(serializer, ipc);
   } 

  @Test public void shouldUploadTeleObservation() throws IOException {
    // Validate that we can upload the observation
    Result result = forwarder.send(teleObs1);
    assertNotNull(result);
    assertTrue( result.isSuccess() );
    
    // and that the IPC transmitted the right data
    String lastPayload = ipc.retrieveLastSentPayload(); 
    //System.out.println( lastPayload );
    assertNotNull( lastPayload );
    // convert the transmitted string back into an observation
    TeleObservation deserial = serializer.deserialize(lastPayload);
    assertEquals( HelperMethods.NANCY_CPR, deserial.getId());
    assertEquals( 70.0, deserial.getDiastolic().getValue(), 0.001);

    // Validate that the server has received the proper data and
    // that the proper XML document is stored.
    Document stored = xds.getLastStoredObservation();
    assertNotNull( stored );
    
    HelperMethods.assertThatDocumentRepresentsObservation120over70forNancy(stored);
    // System.out.println("stored = "+Utility.convertXMLDocumentToString(stored));
    
    // Validate the metadata associated with the observation
    MetaData meta = xds.getLastMetaData();
    assertNotNull( meta ); 
  }
  
  /** Given that a set of tele observations have been stored
   * using home clients, the server should be able to query
   * the XDS for a set of documents fulfilling a given
   * search criteria.
   * @throws IOException 
   */
  @Test public void shouldSupportQueryOnXDS() throws IOException {
    // First - create and upload three observations,
    // two for person 1, and one for person 2
    TeleObservation to1, to2, to3;
    to1 = new TeleObservation("pid001", 130, 80);
    to2 = new TeleObservation("pid001", 125, 85);
    to3 = new TeleObservation("pid002", 180, 90);
    
    // Reset the timestamps of the observations to
    // something known
    final Calendar cal = Calendar.getInstance();
    cal.set(2012,5,1,7,30,00); 
    long at0730 = cal.getTimeInMillis();
    cal.set(2012,5,1,8,30,00); 
    long at0830 = cal.getTimeInMillis();
    cal.set(2012,5,1,10,30,00); 
    long at1030 = cal.getTimeInMillis();
    
    // 7.30 on 1 June 2012
    to1.setTime(at0730);  
    // 10.30 same day
    to2.setTime(at1030); 
    // person 2: same date and between the two times
    to3.setTime(at0830); 
    
    // Upload all three of them
    assertTrue( forwarder.send(to1).isSuccess() );
    assertTrue( forwarder.send(to2).isSuccess() );
    assertTrue( forwarder.send(to3).isSuccess() );
    
    // ================================================================
    // Now the server has translated them to HL7
    // documents and stored them in the XDS,
    // let us try to retrieve them again.
    
    Collection<Document> list; Document[] array; Document doc;

    // ----------------------------------------------------------------
    // First, search for person 1 between 0730 and 1030
    list = xds.retriveDocumentSet( "pid001", at0730, at1030);
    assertEquals( 2, list.size() );
    array = (Document[])list.toArray(new Document[list.size()]);  
      
    // Validate entry 1 
    doc = array[0];
    assertEquals("pid001", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("extension", 0, "id", "patient", doc));
    // The HL7 format is YYYYMMDDHHMMSS for time stamps
    assertEquals("20120601073000", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("value", 0, "effectiveTime", "ClinicalDocument", doc));

    // Validate entry 2 
    doc = array[1];
    assertEquals("pid001", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("extension", 0, "id", "patient", doc));
    assertEquals("20120601103000", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("value", 0, "effectiveTime", "ClinicalDocument", doc));

    // ----------------------------------------------------------------
    // Second, search for person 1 between 0730 and 0830
    list = xds.retriveDocumentSet( "pid001", at0730, at0830);
    assertEquals( 1, list.size() );
    array = (Document[])list.toArray(new Document[list.size()]);  
    doc = array[0];
    assertEquals("20120601073000", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("value", 0, "effectiveTime", "ClinicalDocument", doc));
   
    // ----------------------------------------------------------------
    // Third, search for person 2 between 0730 and 1030
    list = xds.retriveDocumentSet( "pid002", at0730, at1030);
    assertEquals( 1, list.size() );
    array = (Document[])list.toArray(new Document[list.size()]);  
      
    // Validate entry
    doc = array[0];
    assertEquals("pid002", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("extension", 0, "id", "patient", doc));
    // The HL7 format is YYYYMMDDHHMMSS for time stamps
    assertEquals("20120601083000", Utility.getValueOfAttrNamedInNodeIndexNamedEnclosedInNodeInDoc("value", 0, "effectiveTime", "ClinicalDocument", doc));

  }
}
