package cs.saip.domain;

import org.junit.*;
import static org.junit.Assert.*;

import cs.saip.helper.HelperMethods;
import cs.saip.ipc.Serializer;
import cs.saip.ipc.delegate.JacksonJSONSerializer;

/** Learning tests for the TM12 system.
 * Unit testing of TeleObservation and mashalling/unmarshalling.
 * 
 * @author Henrik Baerbak Christensen, Aarhus University
 *
 */
public class TestTeleObservation {

  private TeleObservation to; 
  private Serializer serializer;

  @Before public void setup() {
    to = new TeleObservation(HelperMethods.NANCY_CPR, 120.0, 70.0);
    serializer = new JacksonJSONSerializer();
  } 

  @Test public void shouldCreateTeleObservation() {
    assertEquals( HelperMethods.NANCY_CPR, to.getId());
    assertEquals( 120.0, to.getSystolic().getValue(), 0.001);
    assertEquals( 70.0, to.getDiastolic().getValue(), 0.001);
    assertEquals( "mm(Hg)", to.getSystolic().getUnit() );
  }
  
  @Test public void shouldSerializeToJSON() {
    String json = serializer.serialize(to);
    assertNotNull(json);
    assertTrue( json.contains("\"id\":\""+HelperMethods.NANCY_CPR+"\""));
    assertTrue( json.contains("mm(Hg)"));
    assertTrue( json.contains("{\"value\":120.0,\"unit\""));
    //System.out.println(json);
  }
  
  @Test public void shouldDeserializeFromJSON() {
    String json = serializer.serialize(to);
    TeleObservation deserial = serializer.deserialize(json);
    assertEquals( HelperMethods.NANCY_CPR, deserial.getId());
    assertEquals( 120.0, deserial.getSystolic().getValue(), 0.001);
    assertEquals( 70.0, deserial.getDiastolic().getValue(), 0.001);
    assertEquals( "mm(Hg)", deserial.getSystolic().getUnit() );
  }
}
