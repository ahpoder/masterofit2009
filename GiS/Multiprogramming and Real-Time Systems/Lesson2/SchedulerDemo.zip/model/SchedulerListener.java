package model;

public interface SchedulerListener {
	
	void processAdded(EmulatedProcess process);
}
