package model;

import java.util.*;

import model.EmulatedProcess.ProcessState;

public class FixedPrioritySchedulingAlgorithm implements SchedulingAlgorithmIF {

	public String getName() {
		return "FPS";
	}

	public void updateProcessState(List<EmulatedProcess> emulatedProcesses,
			long tickCount) {

		/* First we check to see if there are any processes, which should be made runnable. */
		for(EmulatedProcess process : emulatedProcesses) {
			switch (process.state) {
			case WAITING :
			case COMPLETED :
			case DEADLINE_MISSED :
				// is it time to release the process again?
				if (isTimeToReleaseProcess(process, tickCount)) {
					releaseProcess(process, tickCount);
				}
				break;
			}
		}
		
		EmulatedProcess processToRun = findProcessToRun(emulatedProcesses);
		for(EmulatedProcess process : emulatedProcesses) {
			switch (process.state) {
			case SUSPENDED :
			case RUNNING :
				if (process.nextAbsoluteDeadline <= tickCount) {
					process.state = ProcessState.DEADLINE_MISSED;
				} else if (process == processToRun) {
					process.state = ProcessState.RUNNING;
					process.remainingWork--;
					if (process.remainingWork == 0) {
						process.state = EmulatedProcess.ProcessState.COMPLETED;
					} 
				} else {
					process.state = ProcessState.SUSPENDED;
				}
				break;
			case COMPLETED :
				process.state = ProcessState.WAITING;
				break;
			default :
				break;
			}
			process.timeTicked();
		}
	}

	public void setupInitialProcessState(List<EmulatedProcess> emulatedProcesses) {
		for(EmulatedProcess process : emulatedProcesses) {
			releaseProcess(process, 0);
		}
	}

	private void releaseProcess(EmulatedProcess process, long tickCount) {
		process.remainingWork = process.C_worstCaseExecutionTime;
		process.nextAbsoluteDeadline = tickCount + process.D_deadlineForCompletion;
		process.justReleased = true;
		
		process.state = EmulatedProcess.ProcessState.SUSPENDED;
	}
	
	/**
	 * Find the process with the highest priority. 
	 * The processes to consider are the ones with state RUNNING or SUSPENDED (the other
	 * processes are not runnable).
	 * @param emulatedProcesses
	 * @return
	 */
	private EmulatedProcess findProcessToRun(List<EmulatedProcess> emulatedProcesses) {
		EmulatedProcess processToRun = null;
		for(EmulatedProcess process : emulatedProcesses) {
			ProcessState state = process.state;
			if (state == ProcessState.RUNNING
				|| state == ProcessState.SUSPENDED) {
				if (processToRun == null) {
					processToRun = process;
				} else {
					if (processToRun.P_priorityOfProcess < process.P_priorityOfProcess) {
						processToRun = process;
					}
				}
			}
		}
		return processToRun;
	}

	
	private boolean isTimeToReleaseProcess(EmulatedProcess process, long tickCount) {
		boolean timeToReleaseProcess = false;
		
		if(tickCount % process.T_processPeriod == 0) {
			timeToReleaseProcess = true;
		}
		
		return timeToReleaseProcess;
	}
}
