package model;

public interface ProcessListener {

	public enum Action {
		RESET,
		TICK,
	}
	
	void processUpdated(Action action, EmulatedProcess process);
}
