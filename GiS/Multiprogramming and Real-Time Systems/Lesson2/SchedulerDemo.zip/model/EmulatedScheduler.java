package model;

import java.util.*;

public class EmulatedScheduler implements ClockListener {

	public static EmulatedScheduler instance = new EmulatedScheduler();
	private List<EmulatedProcess> emulatedProcesses = new ArrayList<EmulatedProcess>();
	private List<SchedulerListener> schedulerListeners = new ArrayList<SchedulerListener>();
	private SchedulingAlgorithmIF algorithm;
	private List<SchedulingAlgorithmIF> algorithmList = new ArrayList<SchedulingAlgorithmIF>();;
	private boolean isRunning;
	
	private EmulatedScheduler() {
		isRunning = false;
		algorithmList.add(new FixedPrioritySchedulingAlgorithm());
		algorithmList.add(new EarliestDeadlineFirstScheduliingAlgorithm());

		algorithm = algorithmList.get(0);
	}
	
	public void addSchedulerListener(SchedulerListener listener) {
		schedulerListeners.add(listener);
	}
	
	public void addEmulatedProcess(EmulatedProcess process) {
		emulatedProcesses.add(process);
		for(SchedulerListener listener : schedulerListeners) {
			listener.processAdded(process);
		}
	}
	
	public List<EmulatedProcess> getEmulatedProcesses() {
		return emulatedProcesses;
	}

	public void setSchedulingAlgorithm(String algorithmName) {
		for(SchedulingAlgorithmIF algorithmIter : algorithmList) {
			if (algorithmName == algorithmIter.getName()) {
				algorithm = algorithmIter;
			}
		}
		reset();
	}
	
	public void reset() {
		Clock clock = Clock.instance;
		clock.stop();
		clock.reset();

		for (EmulatedProcess process : emulatedProcesses) {
			process.reset();
		}

		algorithm.setupInitialProcessState(emulatedProcesses);
	}

	public String[] getSchedulingAlgorithmNames() {
		String[] algorithmNames = new String[algorithmList.size()];
		int algorithmCounter = 0;

		for(SchedulingAlgorithmIF algorithm : algorithmList) {
			algorithmNames[algorithmCounter++] = algorithm.getName();
		}

		return algorithmNames;
	}
	
	public void startScheduler() {
		isRunning = true;
	}
	
	public void stopScheduler() {
		isRunning = false;
	}
	
	/**
	 * @return true if the current process set can be scheduled without missing a deadline
	 */
	public boolean isFeasible() {
		boolean isFeasible = false;
		int wi, wiPlusOne;

		for (EmulatedProcess process : emulatedProcesses) {
			wi = process.C_worstCaseExecutionTime;
			do {
				wiPlusOne = interferenceFromHigherPriorityProcesses(process.P_priorityOfProcess, wi);
				if (wi == wiPlusOne) {
					/* Solution found */
					process.R_worstCaseResponseTime = wi;
					break;
				}
				if (wiPlusOne > process.T_processPeriod) {
					/* No solution */
					break;
				}
				wi = wiPlusOne;
			} while (true);
		}
		
		return isFeasible;
	}
	
	private int interferenceFromHigherPriorityProcesses(int priority, int C) {
		int interference = 0; 
		
		for (EmulatedProcess process : emulatedProcesses) {
			if (process.P_priorityOfProcess > priority) {
				interference += Math.ceil(C/process.T_processPeriod)*process.C_worstCaseExecutionTime;				
			}
		}
		return interference;
	}

	public void timeTicked(Clock clock, long tickCount) {
		if(isRunning) {
			algorithm.updateProcessState(emulatedProcesses, tickCount);
		}
	}
}
