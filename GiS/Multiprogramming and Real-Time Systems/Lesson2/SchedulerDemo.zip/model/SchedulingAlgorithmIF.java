/**
 * 
 */
package model;

import java.util.List;

public interface SchedulingAlgorithmIF {

	public void setupInitialProcessState(List<EmulatedProcess> emulatedProcesses);
	public void updateProcessState(List<EmulatedProcess> emulatedProcesses, long tickCount);
	public String getName();
}
