package model;

import java.util.*;

/**
 * This class represents a schedulable process, including the temporal scope for the process.
 * @author mic
 *
 */
public class EmulatedProcess implements Comparable<EmulatedProcess> {

	public enum ProcessState {
		CREATED,
		RELEASED,
		RUNNING,
		WAITING,
		SUSPENDED,
		COMPLETED,
		DEADLINE_MISSED,
		DESTROYED,
	}
	
	/* Parameters set by GUI */
	public int T_processPeriod = 0;
	public int C_worstCaseExecutionTime = 0;
	public int D_deadlineForCompletion = 0;
	public int P_priorityOfProcess = 0;

	/* Parameters calculated by scheduler */
	public int B_worstCaseBlockingTime = 0;
	public int R_worstCaseResponseTime = 0;
	public int U_utilization = 0;

	public String processName = "";
	public ProcessState state;
	public boolean justReleased = false;
	
	//	public int I_interferenceTime = 0;
	//	public int J_releaseJitter = 0;
	//	public int minimumDelayBeforeStartOfExecution = 0;
	//	public int maximumDelayBeforeStartOfExecution = 0;
	
	public int remainingWork = 0;
	public long nextAbsoluteDeadline = 0;
	public boolean running = false;
	private List<ProcessState> processStateHistory = new ArrayList<ProcessState>();
	private List<ProcessListener> processListeners = new ArrayList<ProcessListener>();
	
	public EmulatedProcess(String processName) {
		this.processName = processName;
		reset();
		addToScheduler();
	}
	
	public void addProcessListener(ProcessListener listener) {
		processListeners.add(listener);
	}
	
	public void addToScheduler() {
		EmulatedScheduler scheduler = EmulatedScheduler.instance;
		scheduler.addEmulatedProcess(this);
	}

	public void reset() {
		state = ProcessState.CREATED;
		processStateHistory.clear();
		processStateHistory.add(state);
		remainingWork = C_worstCaseExecutionTime;
		notifyListeners(ProcessListener.Action.RESET);
	}
	
	public void timeTicked() {
		processStateHistory.add(state);
		notifyListeners(ProcessListener.Action.TICK);
		justReleased = false;
	}
	
	/**
	 * Implement sorting processes by priority. Higher number equals higher priority 
	 */
	public int compareTo(EmulatedProcess process) {
		return process.P_priorityOfProcess - this.P_priorityOfProcess;
	}
	
	private void notifyListeners(ProcessListener.Action action) {
		for(ProcessListener listener : processListeners) {
			listener.processUpdated(action, this);
		}
	}
}
