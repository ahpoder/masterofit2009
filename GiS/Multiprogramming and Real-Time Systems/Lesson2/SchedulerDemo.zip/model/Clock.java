package model;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

import javax.swing.Timer;

public class Clock {

	public static Clock instance = new Clock();
	private final static int CLOCK_TICK_TIME = 750;
	private Timer timer;
	private long tickCount = -1;
	private List<ClockListener> clockListeners = new ArrayList<ClockListener>();

	private Clock() {
		ActionListener task = new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				tick();
			}
		};
		timer = new Timer(CLOCK_TICK_TIME, task);
		timer.setRepeats(true);
		clockListeners.add(EmulatedScheduler.instance);
	}
	
	public void stop() {
		timer.stop();
	}
	
	public void start() {
		timer.start();
	}
	
	public void reset() {
		tickCount = -1;
		for (ClockListener listener : clockListeners) {
			listener.timeTicked(this, tickCount);
		}
	}
	
	public long getTicks() {
		return tickCount;
	}
	
	public void addClockListener(ClockListener listener) {
		clockListeners.add(listener);
	}
	
	private void tick() {
		/* TODO: Som jeg forst�r det, s� vil tick() blive kaldt fra event-dispatching tr�den.
		 * Vi burde derfor ikke f� tr�d problemer! 
		 */
		tickCount++;
		for (ClockListener listener : clockListeners) {
			listener.timeTicked(this, tickCount);
		}
	}
}
