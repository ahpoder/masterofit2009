package model;

public interface ClockListener {
	
	void timeTicked(Clock clock, long tickCount);
	
}
