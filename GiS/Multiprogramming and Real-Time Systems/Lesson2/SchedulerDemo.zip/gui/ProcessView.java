package gui;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;

import java.awt.*;
import model.*;

public class ProcessView
{
	private JPanel processPanel = new JPanel();
	EmulatedProcess process;
	
	public ProcessView(String id) {
		process = new EmulatedProcess(id);
		processPanel.setLayout(new BoxLayout(processPanel, BoxLayout.LINE_AXIS));
		createProcessPropertyElements();
	}
	
	public JPanel getProcessView() {
		return processPanel;
	}
	
	private void createProcessPropertyElements() {
		JLabel nameLabel = new JLabel("Id: " + process.processName);
		processPanel.add(nameLabel);
		processPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		
		JLabel labelPeriod = new JLabel("Period: ");
		processPanel.add(labelPeriod);
		JTextField textFieldPeriod = new JTextField(5);
		textFieldPeriod.setText("" + process.T_processPeriod);
		textFieldPeriod.getDocument().addDocumentListener(new ProcessPeriodChangedListener());
		processPanel.add(textFieldPeriod);
		processPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		
		JLabel labelPriorty = new JLabel("Priority: ");
		processPanel.add(labelPriorty);
		JTextField textFieldPriority = new JTextField(5);
		textFieldPriority.setText("" + process.P_priorityOfProcess);
		textFieldPriority.getDocument().addDocumentListener(new ProcessPriortyChangedListener());
		processPanel.add(textFieldPriority);
		processPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		
		JLabel labelComputationTime = new JLabel("Computation time: ");
		processPanel.add(labelComputationTime);
		JTextField textFieldComputationTime = new JTextField(5);
		textFieldComputationTime.setText("" + process.C_worstCaseExecutionTime);
		textFieldComputationTime.getDocument().addDocumentListener(new ProcessComputationTimeChangedListener());
		processPanel.add(textFieldComputationTime);
		processPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		
		JLabel labelDeadline = new JLabel("Deadline: ");
		processPanel.add(labelDeadline);
		JTextField textFieldDeadline = new JTextField(5);
		textFieldDeadline.setText("" + process.D_deadlineForCompletion);
		textFieldDeadline.getDocument().addDocumentListener(new ProcessDeadlineChangedListener());
		processPanel.add(textFieldDeadline);
		processPanel.add(Box.createRigidArea(new Dimension(5, 0)));
/*		
		JLabel labelUtilization = new JLabel("Utilization: ");
		processPanel.add(labelUtilization);
		JTextField textFieldUtilization = new JTextField(5);
		textFieldUtilization.setText("" + process.U_utilization);
		processPanel.add(textFieldUtilization);
*/
	}

	private int getParameterValue(DocumentEvent e) {
		String string = "0";
		try {
			string = e.getDocument().getText(0, e.getDocument().getLength());
		} catch (BadLocationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int value = 0;
		try {
			value = Integer.parseInt(string.trim());
		} catch (NumberFormatException e1) {}

		return value;
	}
	
	private class ProcessPeriodChangedListener implements DocumentListener {

		public void insertUpdate(DocumentEvent e) { updateProcessPeriod(e); }
		public void removeUpdate(DocumentEvent e) { updateProcessPeriod(e); }
		public void changedUpdate(DocumentEvent e) {}
		
		private void updateProcessPeriod(DocumentEvent e) {
			process.T_processPeriod = getParameterValue(e);
		}
	}

	private class ProcessPriortyChangedListener implements DocumentListener {

		public void insertUpdate(DocumentEvent e) { updateProcessPriorty(e); }
		public void removeUpdate(DocumentEvent e) { updateProcessPriorty(e); }
		public void changedUpdate(DocumentEvent e) {}
		
		private void updateProcessPriorty(DocumentEvent e) {
			process.P_priorityOfProcess = getParameterValue(e);
		}
	}

	private class ProcessComputationTimeChangedListener implements DocumentListener {

		public void insertUpdate(DocumentEvent e) { updateProcessComputationTime(e); }
		public void removeUpdate(DocumentEvent e) { updateProcessComputationTime(e); }
		public void changedUpdate(DocumentEvent e) {}
		
		private void updateProcessComputationTime(DocumentEvent e) {
			process.C_worstCaseExecutionTime = getParameterValue(e);
		}
	}

	private class ProcessDeadlineChangedListener implements DocumentListener {

		public void insertUpdate(DocumentEvent e) { updateProcessDeadline(e); }
		public void removeUpdate(DocumentEvent e) { updateProcessDeadline(e); }
		public void changedUpdate(DocumentEvent e) {}
		
		private void updateProcessDeadline(DocumentEvent e) {
			process.D_deadlineForCompletion = getParameterValue(e);
		}
	}
}
