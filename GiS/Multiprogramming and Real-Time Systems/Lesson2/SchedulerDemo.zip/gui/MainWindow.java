/**
 * 
 */
package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * @author mic
 *
 */
public class MainWindow {

	private JFrame frame = new JFrame("SchedulerDemo");
	private JPanel upperPanel = new JPanel();
	private JPanel lowerPanel = new JPanel();
	private SchedulerView schedulerView;
	private int nextProcessId = 1;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		setNativeLookAndFeel();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				MainWindow mainWindow = new MainWindow();
				mainWindow.createAndShowGUI();
			}
		});
	}
	
	  public static void setNativeLookAndFeel() {
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (Exception e) {
			System.out.println("Error setting native LAF: " + e);
		}
	}
	
	private void createAndShowGUI() {
		schedulerView = new SchedulerView();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		upperPanel.setSize(400, 400);
		upperPanel.add(schedulerView.getSchedulerView());
		
		lowerPanel.setSize(400, 400);
		lowerPanel.setLayout(new BoxLayout(lowerPanel, BoxLayout.PAGE_AXIS));
		
		frame.getContentPane().setLayout(new BorderLayout());
		frame.getContentPane().add(upperPanel, BorderLayout.NORTH);
		frame.getContentPane().add(lowerPanel, BorderLayout.SOUTH);
		
		JPanel buttonPanel = createButtonPanel();
		frame.getContentPane().add(buttonPanel, BorderLayout.CENTER);
		
		frame.pack();
		frame.setVisible(true);
	}

	private JPanel createButtonPanel() {
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
		
		JButton buttonAddProcess = new JButton("Add process");
		buttonAddProcess.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onButtonAddProcessClicked();
			}
		});
		buttonPanel.add(buttonAddProcess);

		buttonPanel.add(schedulerView.getSchedulerControlPanel());
		
		ClockView clockView = new ClockView();
		buttonPanel.add(clockView.getClockPanel());
		
		return buttonPanel;
	}
	
	private void onButtonAddProcessClicked() {
		ProcessView processView = new ProcessView("" + nextProcessId);
		nextProcessId++;
		lowerPanel.add(processView.getProcessView());
		frame.pack();
	}
}
