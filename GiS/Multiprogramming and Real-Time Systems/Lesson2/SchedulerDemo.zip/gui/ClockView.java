package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.Clock;
import model.ClockListener;
import model.EmulatedScheduler;


public class ClockView implements ClockListener {
	private JPanel clockPanel = new JPanel();
	private JTextField ticksTextField = new JTextField(5);
	private boolean firstRun = true;
	Clock clock = Clock.instance;
	
	ClockView() {
		createClockPanel();
		clock.addClockListener(this);
	}
	
	public JPanel getClockPanel() {
		return clockPanel;
	}

	private void createClockPanel() {
		clockPanel.setLayout(new BoxLayout(clockPanel, BoxLayout.X_AXIS));
		
		JButton startButton = new JButton("Start");
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				onStartButtonClicked();
			}
		});
		clockPanel.add(startButton);
		
		JButton stopButton = new JButton("Stop");
		stopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				onStopClicked();
			}
		});
		clockPanel.add(stopButton);
		
		JLabel ticksLabel = new JLabel("Clock ticks: ");
		clockPanel.add(ticksLabel);
		ticksTextField.setEditable(false);
		ticksTextField.setText("" + clock.getTicks());
		clockPanel.add(ticksTextField);
	}
	
	private void onStartButtonClicked() {
		if (firstRun) {
			EmulatedScheduler.instance.reset();
			firstRun = false;
		}
		EmulatedScheduler.instance.startScheduler();
		clock.start();
	}

	private void onStopClicked() {
		EmulatedScheduler.instance.stopScheduler();
		clock.stop();
	}

	public void timeTicked(Clock clock, long tickCount) {
		ticksTextField.setText("" + tickCount);
	}
}
