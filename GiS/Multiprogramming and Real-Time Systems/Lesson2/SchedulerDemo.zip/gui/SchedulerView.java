package gui;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import model.*;

public class SchedulerView implements SchedulerListener {
	private JPanel schedulerViewPanel = new JPanel();
	private JPanel schedulerControlPanel = new JPanel();
	private EmulatedScheduler scheduler = EmulatedScheduler.instance;
	
	private HashMap<EmulatedProcess.ProcessState, Color> colorMap = 
		new HashMap<EmulatedProcess.ProcessState, Color>();
	private HashMap<EmulatedProcess.ProcessState, String> abbrevationMap = 
		new HashMap<EmulatedProcess.ProcessState, String>();  
	
	public SchedulerView() {
		createColorMapping();
		createAbbrevationMapping();
		createSchedulerControlPanel();		
		scheduler.addSchedulerListener(this);
		schedulerViewPanel.setLayout(new BoxLayout(schedulerViewPanel, BoxLayout.Y_AXIS));
	}

	public JPanel getSchedulerView() {
		return schedulerViewPanel;
	}

	public JPanel getSchedulerControlPanel() {
		return schedulerControlPanel;
	}

	public void processAdded(EmulatedProcess process) {
		ScheduledProcessView processView = new ScheduledProcessView(process);
		schedulerViewPanel.add(processView.getScheduledProcessView());
	}

	private void createColorMapping() {
		colorMap.put(EmulatedProcess.ProcessState.CREATED, Color.BLUE);
		colorMap.put(EmulatedProcess.ProcessState.RELEASED, Color.ORANGE);
		colorMap.put(EmulatedProcess.ProcessState.RUNNING, Color.GREEN);
		colorMap.put(EmulatedProcess.ProcessState.WAITING, Color.LIGHT_GRAY);
		colorMap.put(EmulatedProcess.ProcessState.SUSPENDED, Color.WHITE);
		colorMap.put(EmulatedProcess.ProcessState.COMPLETED, Color.CYAN);
		colorMap.put(EmulatedProcess.ProcessState.DEADLINE_MISSED, Color.RED);
		colorMap.put(EmulatedProcess.ProcessState.DESTROYED, Color.BLACK);
	}

	private void createSchedulerControlPanel() {
		schedulerControlPanel.setLayout(new BoxLayout(schedulerControlPanel, BoxLayout.X_AXIS));

		JComboBox algorithmComboBox = new JComboBox(scheduler.getSchedulingAlgorithmNames());
		algorithmComboBox.setSelectedIndex(0);
		algorithmComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onAlgorithmComboBoxChanged(e);
			}
		});
		schedulerControlPanel.add(algorithmComboBox);	

		JButton resetButton = new JButton("Reset");
		resetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				onResetButtonClicked();
			}
		});
		schedulerControlPanel.add(resetButton);			
	}
	
	private void createAbbrevationMapping() {
		abbrevationMap.put(EmulatedProcess.ProcessState.CREATED, "C");
		abbrevationMap.put(EmulatedProcess.ProcessState.RELEASED, "L");
		abbrevationMap.put(EmulatedProcess.ProcessState.RUNNING, "R");
		abbrevationMap.put(EmulatedProcess.ProcessState.WAITING, "W");
		abbrevationMap.put(EmulatedProcess.ProcessState.SUSPENDED, "S");
		abbrevationMap.put(EmulatedProcess.ProcessState.COMPLETED, "D");
		abbrevationMap.put(EmulatedProcess.ProcessState.DEADLINE_MISSED, "M");
		abbrevationMap.put(EmulatedProcess.ProcessState.DESTROYED, "X");
	}

	private void onResetButtonClicked() {
		scheduler.reset();
	}

	private void onAlgorithmComboBoxChanged(ActionEvent e) {
		JComboBox algorithmComboBox = (JComboBox)e.getSource();
		scheduler.setSchedulingAlgorithm((String)algorithmComboBox.getSelectedItem());
	}

	private class ScheduledProcessView {
		JPanel processPanel = new JPanel();
		
		public ScheduledProcessView(EmulatedProcess process) {
			createProcessPanel(process);
		}

		public JPanel getScheduledProcessView() {
			return processPanel;
		}
		
		private void createProcessPanel(EmulatedProcess process) {
			processPanel.setLayout(new BoxLayout(processPanel, BoxLayout.X_AXIS));
			
			JLabel processNameLabel = new JLabel(process.processName);
			processNameLabel.setMaximumSize(new Dimension(20, 50));
			processNameLabel.setSize(new Dimension(20, 50));
			processPanel.add(processNameLabel);
			
			process.addProcessListener(new ProcessListener() {
				public void processUpdated(ProcessListener.Action action, EmulatedProcess process) {
					onProcessUpdated(action, process);
				}
			});
			addStateTick(process);
		}

		private void addStateTick(EmulatedProcess process) {
			JButton state = new JButton(abbrevationMap.get(process.state));
			state.setBackground(colorMap.get(process.state));
			state.setMargin(new Insets(0,0,0,0));
			
			StringBuffer buffer = new StringBuffer();
			buffer.append("<html>");
			buffer.append("Time: " + Long.toString(Clock.instance.getTicks()));
			buffer.append("<br>");
			buffer.append("State: " + process.state);
			buffer.append("<br>");
			buffer.append("Just released: " + process.justReleased);
			buffer.append("<br>");
			buffer.append("Priority: " + process.P_priorityOfProcess);
			buffer.append("<br>");
			buffer.append("Next absolute deadline: " + process.nextAbsoluteDeadline);
			buffer.append("<br>");
			buffer.append("Remaining work: " + process.remainingWork);
			buffer.append("</html>");
			state.setToolTipText(buffer.toString());
			
			Dimension size = new Dimension(20,30);
			state.setMaximumSize(size);
			state.setPreferredSize(size);
			state.setMinimumSize(size);
			
			processPanel.add(state);
		}

		protected void onProcessUpdated(ProcessListener.Action action, EmulatedProcess process) {
			switch (action) {
			case TICK:
				addStateTick(process);
				break;
			case RESET:
				processPanel.removeAll();

				JLabel processNameLabel = new JLabel(process.processName);
				processNameLabel.setMaximumSize(new Dimension(20, 50));
				processNameLabel.setSize(new Dimension(20, 50));
				processPanel.add(processNameLabel);
				addStateTick(process);
				break;
			default:
				break;
			}
			processPanel.updateUI();
		}
	}
}
